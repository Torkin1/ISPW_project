# ISPW_project

This is the repository which contains all deliverables of iNeed project:

- Software Requirement Specification document x1 (includes UC diagram x1, FRs x9 and USs x9);
- Storyboards x6;
- VOPC diagram x3;
- Design Level diagram x3
- UC diagram x1 (for better readability);
- Activity diagram x3;
- Sequence diagram x3;
- State diagram x3;
- SeleniumIDE test x3 (API test are in code repo `iNeed`);
- Demo video x1

iNeed code can be found <a href="https://github.com/LorenzoMei/iNeed">here</a>.
