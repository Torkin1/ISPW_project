# README - TestMakeAnAd.side

There are important infos you should know before running TestMakeAnAd.side:

* A User in DB must exists with **username: prova** and **password: 123**;
* We suppose that the test is passed when we are again in ViewFlow.jsp;

You can tweak these **parameters** inside selenium IDE in order to change targets of test without changing the flow of commands.