# README - TestValidateAFavor.side

There are important infos you should know before running TestValidateAFavor.side:

* A User in DB must exists with **username: prova** and **password: 123**;
* At least one favor that can be validated must exist in DB;

You can tweak these **parameters** inside selenium IDE in order to change targets of test without changing the flow of commands.